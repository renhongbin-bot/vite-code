(function(){const l=document.createElement("link").relList;if(l&&l.supports&&l.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))i(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const s of t.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&i(s)}).observe(document,{childList:!0,subtree:!0});function o(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerpolicy&&(t.referrerPolicy=e.referrerpolicy),e.crossorigin==="use-credentials"?t.credentials="include":e.crossorigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function i(e){if(e.ep)return;e.ep=!0;const t=o(e);fetch(e.href,t)}})();const m="modulepreload",C=function(n){return"/"+n},d={},h=function(l,o,i){if(!o||o.length===0)return l();const e=document.getElementsByTagName("link");return Promise.all(o.map(t=>{if(t=C(t),t in d)return;d[t]=!0;const s=t.endsWith(".css"),g=s?'[rel="stylesheet"]':"";if(!!i)for(let c=e.length-1;c>=0;c--){const a=e[c];if(a.href===t&&(!s||a.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${t}"]${g}`))return;const r=document.createElement("link");if(r.rel=s?"stylesheet":m,s||(r.as="script",r.crossOrigin=""),r.href=t,document.head.appendChild(r),s)return new Promise((c,a)=>{r.addEventListener("load",c),r.addEventListener("error",()=>a(new Error(`Unable to preload CSS for ${t}`)))})})).then(()=>l())},f=`<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 26.0.2, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="图层_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 36 36" style="enable-background:new 0 0 36 36;" xml:space="preserve">
<style type="text/css">
	.st0{opacity:0.561;fill:#A6A69A;enable-background:new    ;}
	.st1{fill:#FFFFFF;}
</style>
<g id="哺乳动物" transform="translate(-239 -441)">
	<g id="组_90" transform="translate(68 158)">
		<circle id="椭圆_11" class="st0" cx="189" cy="301.2" r="18"/>
	</g>
	<g id="组_93" transform="translate(240.046 445.471)">
		<g id="组_94" transform="translate(4.302 3.529)">
			<path id="路径_95" class="st1" d="M12.7,22.8C7,23,2.2,18.6,2,12.9c0-0.3,0-0.5,0-0.8c0-1.4,0.2-2.7,0.6-4
				c-0.8-0.4-1.4-1-1.9-1.7c-1.5-2-0.3-5.6-0.3-5.7l0.1-0.3l0.4-0.1c0.2,0,3.6-0.5,5.1,1.5c0.2,0.3,0.5,0.7,0.6,1.1
				c1.8-1.2,3.9-1.8,6.1-1.8C15,1,17.2,1.7,19,3.1c0.3-0.3,0.5-0.6,0.8-0.9c1.8-1.7,5.1-0.5,5.3-0.5l0.1,0.1v0.3
				c0,0.2,0.5,3.9-1.2,5.6c-0.4,0.4-0.8,0.7-1.3,0.9c0.4,1.1,0.6,2.3,0.5,3.6c0.2,5.7-4.2,10.5-10,10.7
				C13.1,22.8,12.9,22.8,12.7,22.8z M1.4,1.3C1.2,2.2,0.6,4.4,1.5,5.8C2,6.5,2.7,7,3.5,7.4L4,7.5L3.8,8.1C3.3,9.4,3,10.8,3,12.2
				c-0.2,5.1,3.7,9.4,8.8,9.7c0.3,0,0.6,0,0.9,0c5.1,0.2,9.4-3.8,9.7-8.9c0-0.3,0-0.5,0-0.8c0-1.2-0.2-2.5-0.6-3.6l-0.2-0.5l0.5-0.2
				c0.5-0.2,1-0.5,1.4-0.9c1-1,1-3.2,0.9-4.4c-0.7-0.2-2.8-0.7-3.8,0.4c-0.4,0.4-0.7,0.8-0.9,1.2l-0.3,0.5l-0.5-0.5
				c-1.7-1.4-3.9-2.1-6.1-2.1c-2.2,0-4.3,0.7-6,2L6.1,4.6L5.9,3.9c-0.2-0.5-0.5-1-0.8-1.5C4.3,1.3,2.2,1.3,1.4,1.3z"/>
		</g>
		<g id="组_95" transform="translate(11.262 10.647)">
			<path id="路径_96" class="st1" d="M1.7,3.7C1.4,3.7,1.2,3.6,1,3.5C0.1,3-0.2,2,0.1,1.1C0.6,0.3,1.6,0,2.5,0.3
				c0.8,0.5,1.2,1.5,0.8,2.4l0,0C3,3.3,2.4,3.7,1.7,3.7z M1.7,1C1.3,1,1,1.2,0.8,1.5C0.6,2,0.7,2.6,1.2,2.9c0.5,0.2,1.1,0,1.4-0.5
				l0,0c0.3-0.5,0.1-1.1-0.4-1.3c0,0,0,0-0.1,0C2,1,1.8,0.9,1.7,1z"/>
		</g>
		<g id="组_96" transform="translate(19.5 10.647)">
			<path id="路径_97" class="st1" d="M1.7,3.7C1.5,3.7,1.2,3.6,1,3.5C0.6,3.3,0.2,3,0.1,2.5C-0.1,2.1,0,1.6,0.2,1.2
				C0.7,0.3,1.7,0,2.6,0.3c0.4,0.2,0.8,0.6,0.9,1c0.2,0.4,0.1,0.9-0.1,1.4l0,0c-0.2,0.4-0.6,0.8-1,0.9C2.2,3.7,2,3.7,1.7,3.7z
				 M1.7,1C1.4,1,1,1.2,0.8,1.5C0.7,1.8,0.7,2.1,0.7,2.3C0.8,2.6,1,2.8,1.3,2.9C1.5,3,1.8,3,2.1,3c0.3-0.1,0.5-0.3,0.5-0.5l0,0
				c0.1-0.3,0.2-0.5,0.1-0.8C2.6,1.2,2.2,1,1.7,1L1.7,1z"/>
		</g>
		<g id="组_97" transform="translate(13.315 16.161)">
			<path id="路径_98" class="st1" d="M3.6,7.5C1.6,7.5,0,5.8,0,3.8c0-2,1.6-3.6,3.6-3.6s3.6,1.6,3.6,3.6l0,0
				C7.3,5.8,5.7,7.5,3.6,7.5z M3.6,0.9C2,0.9,0.7,2.2,0.7,3.8c0,1.6,1.3,2.9,2.8,2.9c0,0,0,0,0.1,0c1.6,0,2.9-1.3,2.9-2.9
				C6.6,2.2,5.3,0.9,3.6,0.9C3.7,0.9,3.7,0.9,3.6,0.9L3.6,0.9z"/>
		</g>
		<g id="组_98" transform="translate(14.499 18.619)">
			<path id="路径_99" class="st1" d="M1.2,2.6C0.5,2.6,0,2,0,1.4s0.5-1.2,1.2-1.2s1.2,0.5,1.2,1.2l0,0C2.4,2,1.8,2.5,1.2,2.6z
				 M1.2,0.8c-0.3,0-0.5,0.2-0.5,0.5c0,0.3,0.2,0.5,0.5,0.5c0.3,0,0.5-0.2,0.5-0.5l0,0C1.7,1.1,1.5,0.8,1.2,0.8L1.2,0.8z"/>
		</g>
		<g id="组_99" transform="translate(17.231 18.619)">
			<path id="路径_100" class="st1" d="M1.2,2.6C0.5,2.6,0,2,0,1.4s0.5-1.2,1.2-1.2s1.2,0.5,1.2,1.2l0,0C2.4,2,1.8,2.5,1.2,2.6z
				 M1.2,0.8c-0.3,0-0.5,0.2-0.5,0.5c0,0.3,0.2,0.5,0.5,0.5c0.3,0,0.5-0.2,0.5-0.5l0,0C1.7,1.1,1.5,0.8,1.2,0.8L1.2,0.8z"/>
		</g>
	</g>
</g>
</svg>
`;console.log(f);document.body.innerHTML=f;const u=document.getElementsByTagName("svg")[0];u.getElementsByTagName("style")[0];u.onmouseenter=function(){this.style.fill="red"};const p="alice",y="18";h(()=>import("./imageLoader-2fe975b6.js"),[]).then(n=>{console.log(n)});console.log(p,y);fetch("/api/users",{method:"post"}).then(n=>{console.log(n)}).catch(n=>{console.log(n)});
